#include "pipeline.h"
using namespace std;

int main() {
    task5();
    return 0;
}