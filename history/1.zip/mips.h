//
// Created by 23207 on 2020/11/4.
//

/*
 * when func_return:
 *    set $v0
 *    jr $ra
 *    lw $ra, CERTAIN_ADDR
 *
 * when entering a function:
 *    sw $ra, STACK_TOP($sp)
 *    set spaces for:
 *
 * when assignment or initialization:
 *    <some operations>
 *    sw $s, OFFSET($sp)
 *
 * when calling a function:
 *    subi $sp, $sp, TOP_INDEX
 *    jal CALLEE
 *    addi $sp, $sp, TOP_INDEX
 */

#ifndef UNTITLED_MIPS_H
#define UNTITLED_MIPS_H
#include "quard_code.h"
#include "global.h"
#include "mips_command.h"
#include <sstream>

static string random_key = "Wh1tBA12H_";

map<string, int> temp_sym_tab;
map<string ,bool> temp_sym_glob;
map<string, bool> temp_sym_const;
map<string, int> temp_sym_focus;
map<string, int> temp_func_tab;
list<int> jumping_stack;
string cur_func_name;
int top_index = 0;
int over_flow_index = 0;

int str2int(string in) {
    stringstream ss;
    ss << in;
    int size;
    ss >> size;
    return size;
}

bool start_with(string ss, string prefix) {
    if (prefix.size() > ss.size()) return false;
    for (int i = 0;i < prefix.size();i++) {
        if (prefix[i] != ss[i]) return false;
    }
    return true;
}

void push_tab(const string& name, int size, bool is_global) {
    top_index += size;
    temp_sym_tab[name] = top_index;
    temp_sym_glob[name] = is_global;
    temp_sym_const[name] = false;
}

void push_quot(const string& new_name, const string& old_name, bool is_global) {
    temp_sym_tab[new_name] = temp_sym_tab[old_name];
    temp_sym_glob[new_name] = is_global;

    if (temp_sym_const[old_name]) {
        temp_sym_const[new_name] = true;
        temp_sym_focus[new_name] = temp_sym_focus[old_name];
    }
}

void push_func(string name) {
    temp_func_tab[name] = top_index;
}

void push_const(string name, int value) {
    temp_sym_const[name] = true;
    temp_sym_focus[name] = value;
}

static int string_count = 0;
static int s_count = 0;
void set_string() {
    list<Quardcode>::const_iterator iterator;
    for (iterator = qcodes.cbegin(); iterator != qcodes.cend(); iterator++) {
        Quardcode pc = *iterator;
        if (pc.type == "print_s") {
            string string_name = random_key + "string_" + to_string(string_count);
            string_count++;
            allocate_string(string_name, pc.dst);
        }
    }
}

void set_temp_sym_tab() {
    list<Quardcode>::const_iterator iterator;
    bool is_glob = true;
    push_const("std::endl", int('\n'));
    for (iterator = qcodes.cbegin(); iterator != qcodes.cend(); iterator++) {
        Quardcode pc = *iterator;
        if (pc.type == "add" || pc.type == "sub" || pc.type == "mult" || pc.type == "div") {
            push_tab(pc.dst, 4, is_glob);
        }
        else if (pc.type == "li") {
            push_const(pc.dst, str2int(pc.op1));
        } else if (pc.type == "var" || pc.type == "allocate"
        || pc.type == "allocate_init" || pc.type == "para") {
            int size = str2int(pc.op2);
            push_tab(pc.op1, size, is_glob);
        } else if (pc.type == "set_function_flag") {
            top_index = 0;
            is_glob = false;
            push_func(pc.dst);
        } else if (pc.type == "lod") {
            if (!start_with(pc.op1, "@")) push_tab(pc.dst, 4, is_glob);
            push_quot(pc.dst, pc.op1, is_glob);
        }
    }
}

string data_base = "$0";

void qcodes2mips() {
    set_temp_sym_tab();
    list<Quardcode>::const_iterator iterator;
    bool no_func = true;
    set_data_seg();

    for (iterator = qcodes.cbegin(); iterator != qcodes.cend(); iterator++) {
        Quardcode pc = *iterator;
        mout << "# " + pc.to_string() << endl;
        if (pc.type == "add" || pc.type == "sub" || pc.type == "mult" || pc.type == "div") {
            if (!temp_sym_const[pc.op2] && !temp_sym_const[pc.op1]) {
                int addr1 = temp_sym_tab[pc.dst];
                int addr2 = temp_sym_tab[pc.op1];
                int addr3 = temp_sym_tab[pc.op2];
                string base_reg1 = "$sp";
                if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
                string base_reg2 = "$sp";
                if (temp_sym_glob[pc.op1]) base_reg2 = data_base;
                string base_reg3 = "$sp";
                if (temp_sym_glob[pc.op2]) base_reg3 = data_base;

                lw("$t0", addr2, base_reg2);
                lw("$t1", addr3, base_reg3);

                if (pc.type == "add") {
                    add("$t2", "$t0", "$t1");
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "sub") {
                    sub("$t2", "$t0", "$t1");
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "mult") {
                    mult("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                } else if (pc.type == "div") {
                    div("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                }
            }
            else if (!temp_sym_const[pc.op1]){
                int addr1 = temp_sym_tab[pc.dst];
                int addr2 = temp_sym_tab[pc.op1];
                string base_reg1 = "$sp";
                if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
                string base_reg2 = "$sp";
                if (temp_sym_glob[pc.op1]) base_reg2 = data_base;

                lw("$t0", addr2, base_reg2);
                if (pc.type == "add") {
                    addi("$t2", "$t0", to_string(temp_sym_focus[pc.op2]));
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "sub") {
                    subi("$t2", "$t0", to_string(temp_sym_focus[pc.op2]));
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "mult") {
                    li("$t1", to_string(temp_sym_focus[pc.op2]));
                    mult("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                } else if (pc.type == "div") {
                    li("$t1", to_string(temp_sym_focus[pc.op2]));
                    div("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                }
            }
            else if (!temp_sym_const[pc.op2]) {
                int addr1 = temp_sym_tab[pc.dst];
                int addr2 = temp_sym_tab[pc.op2];
                string base_reg1 = "$sp";
                if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
                string base_reg2 = "$sp";
                if (temp_sym_glob[pc.op2]) base_reg2 = data_base;

                lw("$t0", addr2, base_reg2);
                if (pc.type == "add") {
                    addi("$t2", "$t0", to_string(temp_sym_focus[pc.op1]));
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "sub") {
                    li("$t0", to_string(temp_sym_focus[pc.op1]));
                    sub("$t2", "$t0", "$t1");
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "mult") {
                    li("$t1", to_string(temp_sym_focus[pc.op1]));
                    mult("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                } else if (pc.type == "div") {
                    li("$t1", to_string(temp_sym_focus[pc.op1]));
                    div("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                }
            }
            else {
                int addr1 = temp_sym_tab[pc.dst];
                int addr2 = temp_sym_tab[pc.op1];
                string base_reg1 = "$sp";
                if (temp_sym_glob[pc.dst]) base_reg1 = data_base;

                li("$t0", to_string(temp_sym_focus[pc.op1]));
                li("$t1", to_string(temp_sym_focus[pc.op2]));
                if (pc.type == "add") {
                    addi("$t2", "$t0", to_string(temp_sym_focus[pc.op2]));
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "sub") {
                    subi("$t2", "$t0", to_string(temp_sym_focus[pc.op2]));
                    sw("$t2", addr1, base_reg1);
                } else if (pc.type == "mult") {
                    mult("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                } else if (pc.type == "div") {
                    div("$t0", "$t1");
                    mflo("$t0");
                    sw("$t0", addr1, base_reg1);
                }
            }
        }
        else if (pc.type == "multi") {
            int addr1 = temp_sym_tab[pc.dst];
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
            if (temp_sym_const[pc.op1]) {
                li("$t1", to_string(temp_sym_focus[pc.op1]));
            }
            else lw("$t1", addr1, base_reg1);
            li("$t0", pc.op2);
            mult("$t0", "$t1");
            mflo("$t0");
            sw("$t0", addr1, base_reg1);
        }
        else if (pc.type == "lod") {
            if (!start_with(pc.op1, "@")) {
                if (temp_sym_const[pc.op1]) li("$t0", to_string(temp_sym_focus[pc.op1]));
                else lw("$t0", temp_sym_tab[pc.op1], "$0");
                string base_reg = "$sp";
                if (temp_sym_glob[pc.dst]) base_reg = "$0";
                sw("$t0", temp_sym_tab[pc.dst], base_reg);
            }
        }
        else if (pc.type == "lod_off") {
            int dst_addr = temp_sym_tab[pc.dst];
            int src_addr = temp_sym_tab[pc.op1];
            int off_addr = temp_sym_tab[pc.op2];
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
            string base_reg2 = "$sp";
            if (temp_sym_glob[pc.op1]) base_reg2 = data_base;
            string base_reg3 = "$sp";
            if (temp_sym_glob[pc.op2]) base_reg3 = data_base;

            lw("$t0", off_addr, base_reg3);
            neg("$t0", "$t0");
            addi("$t1", "$t0", to_string(src_addr));
            lw("$t0", "$t1", base_reg2);
            sw("$t0", dst_addr, base_reg1);
        }
        else if (pc.type == "allocate") {
            allocate(pc.op1, pc.op2);
        }
        else if (pc.type == "allocate_init") {
            allocate_init(pc.dst, pc.op1, pc.arr);
        }
        else if (pc.type == "initialize_a") {
            int base_addr = temp_sym_tab[pc.dst];
            for (int i = 0;i < pc.arr.size();i++) {
                li("$t0", to_string(pc.arr[i]));
                sw("$t0", (base_addr-4*i), "$sp");
            }
        }
        else if (pc.type == "li") {
            ;
        }
        else if (pc.type == "const") {
            ;
        }
        else if (pc.type == "var" || pc.type == "para") {
            ;
        }
        else if (pc.type == "print_s") {
            la("$a0", random_key + "string_" + to_string(s_count));
            s_count++;
            li("$v0", "4");
            syscall();
        }
        else if (pc.type == "print_v_int") {
            int dst_addr = temp_sym_tab[pc.dst];
            if (temp_sym_const[pc.dst]) {
                li("$a0", to_string(temp_sym_focus[pc.dst]));
            }
            else lw("$a0", dst_addr, "$sp");
            li("$v0", "1");
            syscall();
        }
        else if (pc.type == "print_v_char") {
            int dst_addr = temp_sym_tab[pc.dst];
            if (temp_sym_const[pc.dst]) {
                li("$a0", to_string(temp_sym_focus[pc.dst]));
            }
            else lw("$a0", dst_addr, "$sp");
            li("$v0", "11");
            syscall();
        }
        else if (pc.type == "scanf_int") {
            int dst_addr = temp_sym_tab[pc.dst];
            string base_reg = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg = data_base;
            li("$v0", "5");
            syscall();
            sw("$v0", dst_addr, base_reg);
        }
        else if (pc.type == "scanf_char") {
            int dst_addr = temp_sym_tab[pc.dst];
            string base_reg = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg = data_base;
            li("$v0", "12");
            syscall();
            sw("$v0", dst_addr, base_reg);
        }
        else if (pc.type == "set_function_flag") {
            cur_func_name = pc.dst;
            if (no_func) {
                set_string();
                set_text_seg();
                j("main");
                no_func = false;
            }
            set_flag(pc.dst);
        }
        else if (pc.type == "assign") {
            int dst_addr = temp_sym_tab[pc.dst];
            int src_addr = temp_sym_tab[pc.op1];
            string base_reg2 = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg2 = data_base;
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.op1]) base_reg1 = data_base;

            if (temp_sym_const[pc.op1]) li("$t0", to_string(temp_sym_focus[pc.op1]));
            else lw("$t0", src_addr, base_reg1);
            sw("$t0", dst_addr, base_reg2);
        }
        else if (pc.type == "assign_off") {
            int dst_addr = temp_sym_tab[pc.dst];
            int src_addr = temp_sym_tab[pc.op1];
            int off_addr = temp_sym_tab[pc.op2];
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg1 = data_base;
            string base_reg2 = "$sp";
            if (temp_sym_glob[pc.op1]) base_reg2 = data_base;
            string base_reg3 = "$sp";
            if (temp_sym_glob[pc.op2]) base_reg3 = data_base;

            lw("$t0", off_addr, base_reg3);
            neg("$t0", "$t0");
            addi("$t1", "$t0", to_string(dst_addr));
            if (temp_sym_const[pc.op1]) li("$t0", to_string(temp_sym_focus[pc.op1]));
            else lw("$t0", src_addr, base_reg2);
            sw("$t0", "$t1", base_reg1);
        }
        else if (pc.type == "set_label") {
            set_flag(pc.type + "_" + pc.op1);
        }
        else if (pc.type == "beq" || pc.type == "bne" || pc.type == "ble" ||
        pc.type == "blt" || pc.type == "bge" || pc.type == "bgt") {
            int addr1 = temp_sym_tab[pc.op1];
            int addr2 = temp_sym_tab[pc.op2];
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.op1]) base_reg1 = data_base;
            string base_reg2 = "$sp";
            if (temp_sym_glob[pc.op2]) base_reg2 = data_base;
            lw("$t0", addr1, base_reg1);
            if (temp_sym_const[pc.op2]) {
                branch(pc.type, "$t0", to_string(temp_sym_focus[pc.op2]), pc.dst);
                continue;
            }
            else lw("$t1", addr2, base_reg2);
            branch(pc.type, "$t0", "$t1", pc.dst);

        }
        else if (pc.type == "jump") {
            j(pc.dst);
        }
        else if (pc.type == "set_post_process") {
            int addr1 = temp_sym_tab[pc.op1];
            string base_reg1 = "$sp";
            if (temp_sym_glob[pc.op1]) base_reg1 = data_base;
            lw("$t0", addr1, base_reg1);
            if (pc.op1 == "0") addi("t0", "$t0", pc.op2);
            else subi("$t0", "$t0", pc.op2);
            sw("$t0", addr1, base_reg1);
        }
        else if (pc.type == "call") {
            jumping_stack.push_back(temp_func_tab[cur_func_name] + 4);
            sw("$ra", temp_func_tab[cur_func_name] + 4, "$sp");
            addi("$sp", "$sp", to_string(temp_func_tab[cur_func_name] + 4));
            jal(pc.dst);
        }
        else if (pc.type == "push") {
            if (over_flow_index <= top_index) {
                over_flow_index = top_index + 4;
            } else {
                over_flow_index += 4;
            }
            if (temp_sym_const[pc.dst]) li("$t0", to_string(temp_sym_focus[pc.dst]));
            else lw("$t0", temp_sym_tab[pc.dst], "$0");
            string base_reg = "$sp";
            if (temp_sym_glob[pc.dst]) base_reg = "$0";
            sw("$t0", over_flow_index, base_reg);
        }
        else if (pc.type == "return") {
            jr("$ra");
            lw("$ra", 0, "$sp");
            // set RETURN_VAL
            if (pc.dst == "@None") ;
            else if (temp_sym_const[pc.dst]) li("$v0", to_string(temp_sym_focus[pc.dst]));
            else lw("$v0", temp_sym_tab[pc.dst], "$0");
            // set stack
            int temp_stack_length = jumping_stack.back();
            jumping_stack.pop_back();
            subi("$sp", "$sp", to_string(temp_stack_length));
        }
        else {
                cout << pc.to_string() << endl;
                cout << "#####FATAL ERROR#####";
            }
        }
}

#endif //UNTITLED_MIPS_H
